<script>
    var id=null;
    var name="User";
    var isLogin=0;

    var book_id=0;
    var title="";
    var author="";
    var language="";
    var price=0;
    var stock=0;

    export default {
        //name: "Global",
        //user
        id,
        name,
        isLogin,

        //book
        book_id,
        title,
        author,
        language,
        price,
        stock,
    }
</script>

<style scoped>

</style>
